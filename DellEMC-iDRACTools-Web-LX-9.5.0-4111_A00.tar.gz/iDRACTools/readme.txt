
The package that you downloaded contains the following tools:
� RACADM
� IPMI Tool

==========================================================================================
Release summary
==========================================================================================
The Integrated Dell Remote Access Controller (iDRAC) is designed to make server administrators
more productive and improve the overall availability of Dell servers.

iDRAC alerts administrators to server issues, helps them perform remote server management, and
reduces the need for physical access to the server. Additionally, iDRAC enables administrators
to deploy, monitor, manage, configure, update, and troubleshoot Dell EMC servers from any location
without using any agents. It accomplishes this regardless of the operating system or hypervisor
presence or state.

iDRAC provides out-of-band mechanisms for configuring the server, applying firmware updates,
saving or restoring a system backup, or deploying an operating system, by using the iDRAC GUI, the
iDRAC RESTful API or the RACADM command line interface.

This release of the RACADM command line interface includes updated packaging supporting
the installation of both local and remote RACADM and fixes to issues documented below.

------------------------------------------------------------------------------------------
Version
------------------------------------------------------------------------------------------
Dell EMC iDRAC Tool for Linux  v9.5.0

------------------------------------------------------------------------------------------
Release date
------------------------------------------------------------------------------------------
September 2020

==========================================================================================
Compatibility
==========================================================================================
For SLES 15 systems, the HAPI RPM has a dependency on the 'insserv-compact' OS package.
To ensure backward compatibility, HAPI still uses System V init scripts and has this
dependency. Install this package before installing RACADM.
You can download this package from this link:
http://linuxlib.us.dell.com/pub/Distros/SLES/sles/15/GM/packages/
Module-Basesystem/noarch/insserv-compat-0.1-2.10.noarch.rpm

==========================================================================================
New and enhanced features
==========================================================================================
RACADM:
� Support added for UBUNTU 20.04
  Tracking number: JIT-163190  
�Support added for Custom defaults settings Tracking Number: IDLC-2403
�Support added for RSA integration for 2FA. IDLC-2307
�Support added for Increased password requirement for improved security. Tracking Number:IDLC-2309
�Deprecating getconfig/config subcommands. IDLC-2296


IPMI Tool:
� Added new command "configvalidation" under the delloem 
� Support added for Ubuntu 20.04
� Code refactory for Dell OEM Commands as per open source coding standards.
� CSSD update to 7.16 

==========================================================================================
Fixes
==========================================================================================
RACADM:
 �Fixed issue related to Serial data captured is not exporting fully to Local share executed from remote racadm. Tracking Number: 166887
 �Fixed issue related to Get operation from remote racadm without a success message. Tracking Number: 151802, 154249 
   
IPMI Tool:
 �Fixes for Dell Oem sensor list command 164106 
 �Fixes for FRU write for idrac OEM devices 159193
 �Fixes for Dell Oem mac list command 150926
 �Fixes for mc info command 165967

==========================================================================================
Known issues
==========================================================================================
RACADM:
 � Racadm is not returning the appropriate message when USB controller HUB is disabled in host OS during local Racadm commands operation. Tracking Number: 167532
 � Firmware update from NFS share(with d7 file) updating successfully by throwing error as "session in not valid" from remote racadm. Tracking Number: 170094
	
IPMI Tool:
 N/A


==========================================================================================
Installation
==========================================================================================
RACADM:
1. Navigate to the directory where the tar.gz  of iDRACTools is downloaded.
2. Run tar -zxvf on the tar.gz to unzip the contents into the current directory.
3. Inside the folder where you extracted the files, navigate to /linux/rac folder.
4. To install the RACADM binary, execute the script install_racadm.sh.
   
   Note: Open a new console window to run the RACADM commands. You cannot execute RACADM
   commands from the console window using which you executed the install_racadm.sh script. 
   
   If you get an SSL error message for remote RACADM, use the following steps to
   resolve the error:
   a. Run the command 'openssl version' to find the openssl version installed in the Host OS.
   b. Locate the openSSL libraries that are present in the HOST OS.
      Example: ls -l /usr/lib64/libssl*
   c. Soft-link the library libssl.so using ln -s command to the appropriate OpenSSL 
      version present in the Host OS.
      Example: ln -s /usr/lib64/libssl.so.<version> /usr/lib64/libssl.so

To uninstall RACADM, use the 'uninstall_racadm.sh' script.

Note:
� RACADM and its specific RPMS/Debians can be installed without requiring the installation of OMSA components.
� The installed RACADM binary can be used to execute both Local RACADM and Remote RACADM commands.
� The install_racadm.sh installs only the RPMS/Debians required for RACADM (srvadmin-argtable2, srvadmin-idracadm7, srvadmin-hapi).
� In case of UBUNTU installation, install_racadm.sh and uninstall_racadm.sh scripts has to run using bash as below:
  bash ./install_racadm.sh
  bash ./uninstall_racadm.sh

IPMI Tool:
To install the latest version of RAC Tools, do the following:
1 Uninstall the existing IPMI tool:
	a) Query the existing IPMI tool: rpm -qa | grep ipmitool
	   If the IPMI tool is already installed, the query returns ipmitool-x.x.xx-x.x.xx.
	b) To uninstall the IPMI tool:�
	   On systems running SUSE Linux Enterprise Server  type rpm -e ipmitool-x.x.xx-x.x.xx�
	   On systems running Red Hat Enterprise Linux 6.x, type rpm �e ipmitool�
	   On systems running Red Hat Enterprise Linux 7.x, type rpm �e OpenIPMI-tools
2 Browse to the downloaded DRAC tools directory and got to IPMI tool sub folder and then
  type rpm -ivh ipmitool*.rpm
3 To update already available Dell IPMI Tool type rpm -Uvh ipmitool*.rpm



==========================================================================================
Resources and support
==========================================================================================
------------------------------------------------------------------------------------------
Accessing documents using direct links
------------------------------------------------------------------------------------------
You can directly access the documents using the following links:
� dell.com/idracmanuals		 �	iDRAC and Lifecycle Controller
� dell.com/openmanagemanuals	 �	Enterprise System Management
� dell.com/serviceabilitytools	 �	Serviceability Tools
� dell.com/OMConnectionsClient	 �	Client System Management
� dell.com/OMConnectionsClient	 �	OpenManage Connections Client systems management 
� dell.com/OMConnectionsEnterpriseSystemsManagement � OpenManage Connections Enterprise
                                                      Systems Management

------------------------------------------------------------------------------------------
Accessing documents using product selector
------------------------------------------------------------------------------------------
You can also access documents by selecting your product.
1. Go to dell.com/manuals.
2. In the All products section, click Software --> Enterprise Systems Management.
3. Click the desired product and then click the desired version, if applicable.
4. Click Manuals & documents. 

==========================================================================================
Contacting Dell EMC
==========================================================================================
Dell EMC provides several online and telephone-based support and service options.
Availability varies by country and product, and some services may not be available in
your area. To contact Dell EMC for sales, technical support, or customer service issues,
go to www.dell.com/contactdell.

If you do not have an active Internet connection, you can find contact information on
your purchase invoice, packing slip, bill, or the product catalog.

==========================================================================================
Information in this document is subject to change without notice.
� 2020 Dell Inc. or its subsidiaries. All rights reserved.
Dell, EMC, and other trademarks are trademarks of Dell Inc. or its subsidiaries.
Other trademarks may be trademarks of their respective owners.

Rev: A00